from django.contrib import admin
from .models import *


admin.site.register(MathTopic)


class MathQuestionAdmin(admin.ModelAdmin):
	list_filter = ('belongsTo', )
admin.site.register(MathQuestion, MathQuestionAdmin)


admin.site.register(MathAnswer)
admin.site.register(MathSetSolved)

class MathSetAdmin(admin.ModelAdmin):
	list_filter = ('topic',)
admin.site.register(MathSet, MathSetAdmin)




admin.site.register(UserDetail)
