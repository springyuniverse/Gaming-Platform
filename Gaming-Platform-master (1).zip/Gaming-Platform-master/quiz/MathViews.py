from __future__ import division
from .models import *
from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.contrib.auth.models import  User, Group
from django.contrib import messages, auth
from django.contrib.auth.decorators import login_required

correct = "Right Answer!"
incorrect = "Wrong Answer!"
correctb4 = "Right Answer! But you solved that before! Solve something new!"


# Displaying Math Topics (ex: Addition, Subtraction, Multiplication)
@login_required
def MathList(request):
	queryset = MathTopic.objects.all().order_by('id')

	context = {
		"object_list" : queryset,
		"title" : "Math Topics"
	}

	return render(request, "subject/index.html", context)

# Displaying Sets of a specific topic (ex: Set 1, Set 2)
@login_required
def MathTopicDetail(request, slug):
	topic = get_object_or_404(MathTopic, slug=slug)
	queryset = MathSet.objects.filter(topic = topic.id).order_by('id')
	solvedSets = MathSetSolved.objects.filter(solver = request.user)

	correctlySolvedSets = []
	incorrectlySolvedSets = []

	for s in solvedSets:
		if s.state == True:
			correctlySolvedSets.append(s.solvedSet.id)
		elif s.state == False:
			incorrectlySolvedSets.append(s.solvedSet.id)

	# Unlocking only the current set, enforcing a "difficulty ladder" structure
	locked = []
	for s in queryset:
		if s.id not in correctlySolvedSets:
			locked.append(s.id)
	locked.pop(0)

	context = {
		"title" : topic.name,
		"topic" : topic,
		"object_list" : queryset,
		"correctly_solved_list" : correctlySolvedSets,
		"incorrectly_solved_list" : incorrectlySolvedSets,
		"locked_list" : locked,
	}

	return render(request, "subject/topic.html", context)

# Displaying questions 
@login_required
def MathSetDetail(request, topic, pk):
	thisSet = get_object_or_404(MathSet, pk = pk)
	queryset = MathQuestion.objects.filter(belongsTo = thisSet.id).order_by('id')
	solved = MathAnswer.objects.filter(solver =  request.user)
	
	correctlySolvedSet = []
	incorrectlySolvedSet = []

	for q in solved:
		if q.state == True: 
			correctlySolvedSet.append(q.question.id)
		elif q.state == False:
			incorrectlySolvedSet.append(q.question.id)

	context = {
		"object_list" : queryset,
		"correctly_solved_list" : correctlySolvedSet,
		"incorrectly_solved_list" : incorrectlySolvedSet,
		"title" :  topic.title() + ": " + thisSet.name,
	}

	return render(request, "subject/questions.html", context)

@login_required
def MathQuestionDetail(request, topic, id, pk):
	thisSet = get_object_or_404(MathSet, pk = pk)
	queryset = MathQuestion.objects.filter(belongsTo = thisSet.id).order_by('id')

	instance = get_object_or_404(MathQuestion, id = id)
	user = get_object_or_404(UserDetail, user = request.user)
	solved = MathAnswer.objects.filter(solver = request.user, question = instance, state = True)

	def get_next():
		next = queryset.filter(id__gt=id)
		if next:
			return next.first().id
		return False
	if get_next():
		next = get_next()
	else:
		next = ''

	def get_prev():
		prev = queryset.filter(id__lt=id).order_by('-id')
		if prev:
		  return prev.first().id
		return False
	if get_prev():
		prev = get_prev()
	else:
		prev = ''

	# Storing exact answers alongside true and false in order to use it for analytical purposes in the future
	if request.method == "POST":
		userAnswer = request.POST["option"]
		if userAnswer == instance.answer:
			if not solved:
				user.score = user.score + instance.points
				user.save()
				MathAnswer.objects.create(solver = request.user.username, question = instance, answer = userAnswer, state = True)
		else:
			MathAnswer.objects.create(solver = request.user.username, question = instance, answer = userAnswer, state = False)
		
		if next: #Redirecting to next question
			url = "/math/" + thisSet.topic.slug + "/" + pk + "/" + str(next) + "/"
			return redirect(url)
		else: # Executes if questions of this set are finished 
			totalSolvedCorrectly = 0
			for q in queryset:
				if MathAnswer.objects.filter(solver = request.user, question = q, state = True):
					totalSolvedCorrectly += 1
			request.session['total'] = totalSolvedCorrectly
			request.session['outof'] = len(queryset)
			print(totalSolvedCorrectly/len(queryset))
			if totalSolvedCorrectly/len(queryset) > 0.50:
				MathSetSolved.objects.create(solver = request.user.username, solvedSet = thisSet, state = True)
			else:
				MathSetSolved.objects.create(solver = request.user.username, solvedSet = thisSet, state = False)
			return redirect("/math/progress/")

	context = {
		"title" : instance.question,
		"object" : instance,
		"topic" : thisSet.topic.slug,
		"set" : pk,
	}
	return render(request, "subject/detail.html", context)

def MathProgress(request):
	total = request.session['total']
	outof = request.session['outof']
	context = {
		"total" : total, 
		"outof" : outof
	}
	return render(request, "subject/progress.html", context)

